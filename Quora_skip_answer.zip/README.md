quora-skip-answer
=================

Skip extra-long quora answers